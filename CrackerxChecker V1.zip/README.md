Telegram : https://t.me/UnkownxArmy Join For More ! 
"Don't remove copyright."